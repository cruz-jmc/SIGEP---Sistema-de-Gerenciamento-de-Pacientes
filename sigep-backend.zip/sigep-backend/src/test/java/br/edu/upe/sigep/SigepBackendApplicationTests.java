package br.edu.upe.sigep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SigepBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
